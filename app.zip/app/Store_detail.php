<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Store_detail extends Model
{
    //
}
