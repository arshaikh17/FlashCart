<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Store_product_area extends Model
{
    //
}
