<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Flashcart_request extends Model
{
    //
}
