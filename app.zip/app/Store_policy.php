<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Store_policy extends Model
{
    //
}
