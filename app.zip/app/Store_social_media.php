<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Store_social_media extends Model
{
    protected $table = 'store_social_medias';
}
