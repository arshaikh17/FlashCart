<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Store_user_conversation_message extends Model
{
    //
}
