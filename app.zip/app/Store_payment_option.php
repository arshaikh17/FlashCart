<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Store_payment_option extends Model
{
    //
}
