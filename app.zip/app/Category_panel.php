<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category_panel extends Model
{
    //
}
