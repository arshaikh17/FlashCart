<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Policy_area extends Model
{
    //
}
