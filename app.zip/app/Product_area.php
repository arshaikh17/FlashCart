<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product_area extends Model
{
    //
}
