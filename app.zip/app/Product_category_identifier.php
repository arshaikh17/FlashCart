<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product_category_identifier extends Model
{
    //
}
