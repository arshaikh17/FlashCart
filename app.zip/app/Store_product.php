<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use Elasticquent\ElasticquentTrait;
class Store_product extends Model
{
    //
      use ElasticquentTrait;
}