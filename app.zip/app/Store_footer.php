<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Store_footer extends Model
{
    //
}
