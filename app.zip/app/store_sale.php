<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class store_sale extends Model
{
    //
}
