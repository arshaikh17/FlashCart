<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Store_single_product extends Model
{
    //
}
