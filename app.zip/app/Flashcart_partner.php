<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Flashcart_partner extends Model
{
    //
}
